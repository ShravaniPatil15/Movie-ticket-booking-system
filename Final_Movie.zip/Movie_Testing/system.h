#include "acc_hash.h"
#include "pin_hash.h"
#include "movie_hash.h"
#include <stdio.h>

struct booking_details
{
    char name[25]; //Name of the person who has booked the ticket
    long int phone;
    int movie_no;
    int seat;
    int id;
};

struct booking_details person[500];

int changeprice(int);
void reservation(int *array, int price,int selection, char *movie_name);
int choice1();
void cancel(int *array, int price);        
int canc_movie_num();
void details();
int UpdateAccountBalance(char *name, int price); //returns updated balance  of the Username's Account Number.
void put_movies();
//int RefundMoney(char *name, int price);